#ifndef PORTABLE_H
#define PORTABLE_H

#include "portmacro.h"


#endif /* PORTABLE_H */
